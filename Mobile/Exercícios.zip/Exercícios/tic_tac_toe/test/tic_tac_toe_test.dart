import 'package:tic_tac_toe/tic_tac_toe.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
